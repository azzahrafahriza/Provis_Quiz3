package com.example.quiz3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}



import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuis 3 - Kelompok 6',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BlocProvider(
        create: (context) => LoanCubit(),
        child: MyHomePage(),
      ),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text("My App P2P")),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(25.0),
            child: Text(
              "2102296, Azzahra Fahriza; 2101330, Talitha Syahla; Saya Berjanji tidak akan berbuat curang data atau membantu orang lain berbuat curang",
              style: TextStyle(fontSize: 15.0),
            ),
          ),
          LoanDropdown(),
          Expanded(
            child: LoanList(),
          ),
        ],
      ),
    );
  }
}

class LoanCubit extends Cubit<List<dynamic>> {
  LoanCubit() : super([]);

  Future<void> fetchData(String jenis) async {
    final response = await http
        .get(Uri.parse('http://178.128.17.76:8000/umkm/1234?jenis=$jenis'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body)['data'];
      emit(data);
    }
  }
}

class LoanDropdown extends StatefulWidget {
  @override
  _LoanDropdownState createState() => _LoanDropdownState();
}

class _LoanDropdownState extends State<LoanDropdown> {
  String _selectedOption = "Pilih jenis pinjaman";
  List<String> _options = [
    "Pilih jenis pinjaman",
    "Jenis pinjaman 1",
    "Jenis pinjaman 2",
    "Jenis pinjaman 3",
  ];

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: _selectedOption,
      items: _options.map((String option) {
        return DropdownMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
      onChanged: (String? newValue) {
        setState(() {
          _selectedOption = newValue!;
          if (_selectedOption == 'Jenis pinjaman 1') {
            context.read<LoanCubit>().fetchData('1');
          } else if (_selectedOption == 'Jenis pinjaman 2') {
            context.read<LoanCubit>().fetchData('2');
          } else if (_selectedOption == 'Jenis pinjaman 3') {
            context.read<LoanCubit>().fetchData('3');
          } else {
            context.read<LoanCubit>().fetchData('');
          }
        });
      },
      hint: Text("Jenis Pinjaman"),
    );
  }
}

class DetailPage extends StatelessWidget {
  final String data;

  DetailPage({required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Peminjaman'),
      ),
      body: Center(
        child: Text('ID : $data'),
      ),
    );
  }
}

class LoanList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoanCubit, List<dynamic>>(
      builder: (context, state) {
        if (state.isEmpty) {
          return Center(
            child: Text(" "),
          );
        } else {
          return ListView.builder(
            itemCount: state.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                leading: Image.network(
                  'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl-2.jpg',
                  width: 50,
                  height: 50,
                ),
                title: Text(state[index]['nama']),
                subtitle: Text("ID: ${state[index]['id']}"),
                trailing: Icon(Icons.more_vert),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          DetailPage(data: state[index]['id']),
                    ),
                  );
                },
              );
            },
          );
        }
      },
    );
  }
}
